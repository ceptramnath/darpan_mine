class ValidationData {
  late String param1;

  late String param2;

  late String param3;

  late String param4;
}
