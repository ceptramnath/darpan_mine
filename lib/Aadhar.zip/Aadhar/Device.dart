class Device {
  late String dc;

  late String dpId;

  late String mc;

  late String mi;

  late String rdsId;

  late String rdsVer;
}
