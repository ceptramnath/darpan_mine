class Uses {
  late String bio;

  late String bt;

  late String otp;

  late String pa;

  late String pfa;

  late String pi;

  late String pin;
}
