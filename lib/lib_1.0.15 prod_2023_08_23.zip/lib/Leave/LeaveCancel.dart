import 'package:flutter/material.dart';

class leaveCancel extends StatefulWidget {
  @override
  _leaveCancelState createState() => _leaveCancelState();
}

class _leaveCancelState extends State<leaveCancel> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold();
  }
}
