import 'package:darpan/Authentication/db/registrationdb.dart';
import 'package:darpan/Constants/Color.dart';
import 'package:darpan/INSURANCE/Utils/DateTimeDetails.dart';
import 'package:darpan/INSURANCE/Widget/Loader.dart';
import 'package:darpan/Mails/Booking/BookingDBModel/BookingDBModel.dart';
import 'package:darpan/Mails/Booking/BookingMainScreen.dart';
import 'package:darpan/Mails/Booking/Services/BookingDBService.dart';
import 'package:darpan/Mails/BookingServices.dart';
import 'package:darpan/Utils/Printing.dart';
import 'package:darpan/Utils/Receipt.dart';
import 'package:darpan/Widgets/Button.dart';
import 'package:darpan/Widgets/Button1.dart';
import 'package:darpan/Widgets/DialogCommonWidgets.dart';
import 'package:darpan/Widgets/DialogCommonWidgets1.dart';
import 'package:darpan/Widgets/DialogText.dart';
import 'package:darpan/Widgets/UITools.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:intl/intl.dart';

class RLConformationDialog extends StatefulWidget {
  final String articleNumber,
      weight,
      weightAmount,
      prepaidAmount,
      insurance,
      registrationFee,
      valuePayablePost,
      amountToBeCollected,
      senderName,
      senderAddress,
      senderPinCode,
      senderCity,
      senderState,
      senderMobileNumber,
      senderEmail,
      addresseeName,
      addresseeAddress,
      addresseePinCode,
      addresseeCity,
      addresseeState,
      addresseeMobileNumber,
      addresseeEmail,
      paymentMode;
  final bool acknowledgement;
  final Function() function;

  RLConformationDialog(
      {required this.articleNumber,
      required this.weight,
      required this.weightAmount,
      required this.prepaidAmount,
      required this.acknowledgement,
      required this.insurance,
      required this.registrationFee,
      required this.valuePayablePost,
      required this.amountToBeCollected,
      required this.senderName,
      required this.senderAddress,
      required this.senderPinCode,
      required this.senderCity,
      required this.senderState,
      required this.senderMobileNumber,
      required this.senderEmail,
      required this.addresseeName,
      required this.addresseeAddress,
      required this.addresseePinCode,
      required this.addresseeCity,
      required this.addresseeState,
      required this.addresseeMobileNumber,
      required this.addresseeEmail,
      required this.function,
      required this.paymentMode});

  @override
  _RLConformationDialogState createState() => _RLConformationDialogState();
}

class _RLConformationDialogState extends State<RLConformationDialog> {
  PdfGeneration pdfScreen = new PdfGeneration();
  List<String> basicInformation = <String>[];
  List<String> secondReceipt = <String>[];
  String pdfName = "";
  bool _clicked=false;

  GeneratePDF() async {
    final userDetails = await OFCMASTERDATA().select().toList();

    String date = DateTimeDetails().currentDate();
    String time = DateTimeDetails().oT();

    basicInformation.add("Transaction Date");
    basicInformation.add(date);
    basicInformation.add("Transaction Time");
    basicInformation.add(time);
    basicInformation.add("Booking Office");
    basicInformation.add(userDetails[0].BOName.toString());
    basicInformation.add("Booking Office PIN");
    basicInformation.add(userDetails[0].Pincode.toString());
    basicInformation.add("BPM");
    basicInformation.add(userDetails[0].EmployeeName.toString());
    basicInformation.add("Article Number");
    basicInformation.add(widget.articleNumber);
    basicInformation.add("Service");
    basicInformation.add("Regd. Letter");
    basicInformation.add("Weight");
    basicInformation.add(widget.weight);
    basicInformation.add("Payment Mode");
    basicInformation.add(widget.paymentMode);
    basicInformation.add("Prepaid");
    basicInformation.add(widget.prepaidAmount);

    basicInformation.add("Paid Amount");
    basicInformation.add(widget.amountToBeCollected);
    basicInformation.add("Sender Name");
    basicInformation.add(widget.senderName);
    basicInformation.add("Addressee Name");
    basicInformation.add(widget.addresseeName);
    basicInformation.add("Delivery Office");
    basicInformation.add(widget.addresseeCity);
    basicInformation.add("Delivery Office Pincode");
    basicInformation.add(widget.addresseePinCode);
    basicInformation.add("Track - ");
    basicInformation.add("www.indiapost.gov.in");
    basicInformation.add("|< Dial :");
    basicInformation.add("18002666868>|");
    basicInformation.add("|< IVR Track #:");
    basicInformation.add("6975000000028 >|");

    secondReceipt.clear();

    secondReceipt.add("Transaction Date");
    secondReceipt.add(date);
    secondReceipt.add("Booking Office");
    secondReceipt.add(userDetails[0].BOName.toString());
    secondReceipt.add("Booking Office PIN");
    secondReceipt.add(userDetails[0].Pincode.toString());
    secondReceipt.add("BPM");
    secondReceipt.add(userDetails[0].EmployeeName.toString());
    secondReceipt.add("Service");
    secondReceipt.add("Regd. Letter");
    secondReceipt.add("Article Number");
    secondReceipt.add(widget.articleNumber);
    secondReceipt.add("Weight");
    secondReceipt.add(widget.weight);
    secondReceipt.add("Payment Mode");
    secondReceipt.add(widget.paymentMode);
    secondReceipt.add("Paid Amount");
    secondReceipt.add(widget.amountToBeCollected);
    secondReceipt.add("Sender Name");
    secondReceipt.add(widget.senderName);

    // print('basic information is');
    // print(basicInformation.toString());
    //
    // String generatedPdfFilePath = await pdfScreen.generateExampleDocument(
    //     "Regd. Letter", basicInformation, [], [], [], [], "", "", "", "",widget.articleNumber);
    //
    //
    //
    // print("File Path is - " + generatedPdfFilePath.toString());
    // pdfName=generatedPdfFilePath.toString();
    // return  generatedPdfFilePath.toString();
  }
  SendSms()  async {
    //Checking whether Mobile Number entered or not
    if(widget.senderMobileNumber.length !=10) {
      print(widget.senderMobileNumber);
      showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context)
          {
            return AlertDialog(
              title: const Text(
                  'Information'),
              content: Text(
                  'Invalid Mobile Number!'),
              actions: [
                Button(
                    buttonText: 'OKAY',
                    buttonFunction: () =>
                        Navigator.of(context)
                            .pop()
                )


              ],
            );
          });
    }
    else
    {
      //Send SMS
      //Get Details from the Database
      print("Inside Send Booking SMS");
      String ret="";
      String poptext="";
      BookingDBService bs= new BookingDBService();
      ret= await bs.SendBookingSMS('RL',widget.articleNumber,widget.senderMobileNumber);
      print(ret);
      //print("xvacvsdhvcsj");
      if(ret=="Success") {
        poptext = "SMS Sent Successfully!";
        _clicked=true;
      }
      else
        poptext="Unable to send SMS !";

      showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context)
          {
            return AlertDialog(
              title: const Text(
                  'Information'),
              content: Text(
                  poptext),
              actions: [
                Button(
                    buttonText: 'OKAY',
                    buttonFunction: () =>
                        Navigator.of(context)
                            .pop()
                )
              ],
            );
          }
      );
    }}

  @override
  void initState() {
    print("Payment mode is ${widget.paymentMode}");
    checkForTexts();
    GeneratePDF();
    print("initState file path-" + pdfName);
    super.initState();
  }

  bool acknowledgementCheck = false;
  bool insuranceCheck = false;
  bool vppCheck = false;
  bool senderMobCheck = false;
  bool senderEmailCheck = false;
  bool addresseeMobCheck = false;
  bool addresseeEmailCheck = false;
  bool visiblty = false;

  checkForTexts() {
    print("Inside check for texts");
    setState(() {
      widget.acknowledgement == true
          ? acknowledgementCheck = true
          : acknowledgementCheck = false;
      widget.insurance.isNotEmpty
          ? insuranceCheck = true
          : insuranceCheck = false;
      widget.valuePayablePost.isNotEmpty ? vppCheck = true : vppCheck = false;
      widget.senderMobileNumber.isNotEmpty
          ? senderMobCheck = true
          : senderMobCheck = false;
      widget.senderEmail.isNotEmpty
          ? senderEmailCheck = true
          : senderEmailCheck = false;
      widget.addresseeMobileNumber.isNotEmpty
          ? addresseeMobCheck = true
          : addresseeMobCheck = false;
      widget.addresseeEmail.isNotEmpty
          ? addresseeEmailCheck = true
          : addresseeEmailCheck = false;
    });
  }


  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [ Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.toDouble()))),
        elevation: 0,
        backgroundColor: ColorConstants.kWhite,
        child: _data(context),
      ),
        visiblty == true
            ? Center(
            child: Loader(
                isCustom: true, loadingTxt: 'Please Wait...Loading...'))
            : const SizedBox.shrink()
      ]
    );
  }

  _data(BuildContext context) => SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const DialogHeader(),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0.toDouble()),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //Article Details
                  DialogText(
                      title: 'Article Number : ',
                      subtitle: widget.articleNumber),
                  const Space(),
                  DialogText(
                      title: 'Weight : ', subtitle: '${widget.weight} gms'),
                  const Space(),
                  DialogText(
                      title: 'Prepaid Amount : ',
                      subtitle: '\u{20B9} ${widget.prepaidAmount}'),
                  const Space(),
                  Row(
                    children: [
                      Expanded(
                        flex: widget.acknowledgement ? 1 : 0,
                        child: Visibility(
                          visible: widget.acknowledgement,
                          child: DialogText(
                              title: 'Acknowledge\nAmount\n',
                              subtitle: widget.insurance.isNotEmpty
                                  ? '\u{20B9} 0'
                                  : '\u{20B9} 3'),
                        ),
                      ),
                      Expanded(
                        flex: widget.insurance != '' ? 1 : 0,
                        child: Visibility(
                          visible: widget.insurance != '',
                          child: DialogText(
                              title: 'Insurance\nAmount\n',
                              subtitle: '\u{20B9} ${widget.insurance}'),
                        ),
                      ),
                      Expanded(
                        flex: widget.valuePayablePost != '' ? 1 : 0,
                        child: Visibility(
                          visible: widget.valuePayablePost != '' ? true : false,
                          child: DialogText(
                              title: 'VPP \nAmount\n',
                              subtitle: '\u{20B9} ${widget.valuePayablePost}'),
                        ),
                      ),
                    ],
                  ),
                  const Space(),
                  DialogText(
                      title: 'Register Letter fee : ',
                      subtitle: '\u{20B9} ${widget.registrationFee}'),
                  const Space(),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                        text: 'Amount to be paid : ',
                        style: TextStyle(
                          color: ColorConstants.kTextColor,
                          letterSpacing: 1,
                          fontSize: 15.toDouble(),
                        ),
                        children: [
                          TextSpan(
                              text: '\u{20B9} ${widget.amountToBeCollected}',
                              style: TextStyle(
                                  fontSize: 15.toDouble(),
                                  color: ColorConstants.kTextDark,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.toDouble()))
                        ]),
                  ),
                  const Space(),
                  DialogText(
                      title: 'Payment Mode : ', subtitle: widget.paymentMode),
                  const DoubleSpace(),

                  //Sender Details
                  DialogText(
                      title: 'Sender : ', subtitle: '${widget.senderName}'),
                  const Space(),
                  Flexible(
                    child: Padding(
                      padding: EdgeInsets.only(left: 8.0.toDouble()),
                      child: Text(widget.senderAddress +
                          ", " +
                          widget.senderCity +
                          ", " +
                          widget.senderState +
                          ", " +
                          widget.senderPinCode),
                    ),
                  ),
                  const Space(),
                  Visibility(
                      visible: senderMobCheck,
                      child: DialogText(
                        title: 'Mob# : ',
                        subtitle: widget.senderMobileNumber,
                      )),
                  const Space(),
                  Visibility(
                      visible: senderEmailCheck,
                      child: DialogText(
                        title: 'Email ID : ',
                        subtitle: widget.senderEmail,
                      )),
                  const DoubleSpace(),

                  //Addressee Details
                  DialogText(
                      title: 'Addressee : ', subtitle: widget.addresseeName),
                  const Space(),
                  Flexible(
                    child: Padding(
                      padding: EdgeInsets.only(left: 8.0.toDouble()),
                      child: Text(widget.addresseeAddress +
                          ", " +
                          widget.addresseeCity +
                          ", " +
                          widget.addresseeState +
                          ", " +
                          widget.addresseePinCode),
                    ),
                  ),
                  const Space(),
                  Visibility(
                      visible: addresseeMobCheck,
                      child: DialogText(
                        title: 'Mob# : ',
                        subtitle: widget.addresseeMobileNumber,
                      )),
                  const Space(),
                  Visibility(
                      visible: addresseeEmailCheck,
                      child: DialogText(
                        title: 'Email ID : ',
                        subtitle: widget.addresseeEmail,
                      )),
                  const Space(),
                ],
              ),
            ),
            const Space(),
            Container(
              decoration: BoxDecoration(
                  color: ColorConstants.kPrimaryAccent,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10.toDouble()),
                      bottomRight: Radius.circular(10.toDouble()))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Button(
                      buttonText: 'CANCEL',
                      buttonFunction: () => Navigator.of(context).pop()),
                  Button(
                      buttonText: 'BOOK',
                      buttonFunction: () {
                        setState(() {
                          visiblty =true;
                        });
                        print("Before widget function running");
                        widget.function();
                        showDialog<void>(
                            context: context,
                            barrierDismissible: false,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title:  Text('${widget.articleNumber} Booking Confirmation'),
                                content:
                                Container(
                                  child: SingleChildScrollView(
                                      child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .stretch,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          mainAxisSize:
                                          MainAxisSize.min,
                                          children: [
                                            DialogHeader1(),
                                            Padding(
                                              padding: EdgeInsets.symmetric(horizontal: 0.0.toDouble()),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  //Article Details
                                                  DialogText(
                                                      title: 'Article Number : ',
                                                      subtitle: widget.articleNumber),
                                                  const Space(),
                                                  DialogText(
                                                      title: 'Weight : ', subtitle: '${widget.weight} gms'),
                                                  const Space(),
                                                  DialogText(
                                                      title: 'Prepaid Amount : ',
                                                      subtitle: '\u{20B9} ${widget.prepaidAmount}'),
                                                  const Space(),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        flex: widget.acknowledgement ? 1 : 0,
                                                        child: Visibility(
                                                          visible: widget.acknowledgement,
                                                          child: DialogText(
                                                              title: 'Acknowledge\nAmount\n',
                                                              subtitle: widget.insurance.isNotEmpty
                                                                  ? '\u{20B9} 0'
                                                                  : '\u{20B9} 3'),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: widget.insurance != '' ? 1 : 0,
                                                        child: Visibility(
                                                          visible: widget.insurance != '',
                                                          child: DialogText(
                                                              title: 'Insurance\nAmount\n',
                                                              subtitle: '\u{20B9} ${widget.insurance}'),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: widget.valuePayablePost != '' ? 1 : 0,
                                                        child: Visibility(
                                                          visible: widget.valuePayablePost != '' ? true : false,
                                                          child: DialogText(
                                                              title: 'VPP \nAmount\n',
                                                              subtitle: '\u{20B9} ${widget.valuePayablePost}'),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  const Space(),
                                                  DialogText(
                                                      title: 'Registration fee : ',
                                                      subtitle: '\u{20B9} ${widget.registrationFee}'),
                                                  const Space(),
                                                  RichText(
                                                    textAlign: TextAlign.center,
                                                    text: TextSpan(
                                                        text: 'Amount paid : ',
                                                        style: TextStyle(
                                                          color: ColorConstants.kTextColor,
                                                          letterSpacing: 1,
                                                          fontSize: 15.toDouble(),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                              text: '\u{20B9} ${widget.amountToBeCollected}',
                                                              style: TextStyle(
                                                                  fontSize: 15.toDouble(),
                                                                  color: ColorConstants.kTextDark,
                                                                  fontWeight: FontWeight.bold,
                                                                  letterSpacing: 1.toDouble()))
                                                        ]),
                                                  ),
                                                  const Space(),
                                                  DialogText(
                                                      title: 'Payment Mode : ', subtitle: widget.paymentMode),
                                                  const Space(),

                                                  //Sender Details
                                                  DialogText(
                                                      title: 'Sender : ', subtitle: '${widget.senderName}'),

                                                  Flexible(
                                                    child: Padding(
                                                      padding: EdgeInsets.only(left: 8.0.toDouble()),
                                                      child: Text(widget.senderAddress +
                                                          ", " +
                                                          widget.senderCity +
                                                          ", " +
                                                          widget.senderState +
                                                          ", " +
                                                          widget.senderPinCode),
                                                    ),
                                                  ),
                                                  const Space(),
                                                  Visibility(
                                                      visible: senderMobCheck,
                                                      child: DialogText(
                                                        title: 'Mob# : ',
                                                        subtitle: widget.senderMobileNumber,
                                                      )),
                                                  const Space(),
                                                  Visibility(
                                                      visible: senderEmailCheck,
                                                      child: DialogText(
                                                        title: 'Email ID : ',
                                                        subtitle: widget.senderEmail,
                                                      )),
                                                  const Space(),

                                                  //Addressee Details
                                                  DialogText(
                                                      title: 'Addressee : ', subtitle: widget.addresseeName),

                                                  Flexible(
                                                    child: Padding(
                                                      padding: EdgeInsets.only(left: 8.0.toDouble()),
                                                      child: Text(widget.addresseeAddress +
                                                          ", " +
                                                          widget.addresseeCity +
                                                          ", " +
                                                          widget.addresseeState +
                                                          ", " +
                                                          widget.addresseePinCode),
                                                    ),
                                                  ),
                                                  const Space(),
                                                  Visibility(
                                                      visible: addresseeMobCheck,
                                                      child: DialogText(
                                                        title: 'Mob# : ',
                                                        subtitle: widget.addresseeMobileNumber,
                                                      )),
                                                  const Space(),
                                                  Visibility(
                                                      visible: addresseeEmailCheck,
                                                      child: DialogText(
                                                        title: 'Email ID : ',
                                                        subtitle: widget.addresseeEmail,
                                                      )),
                                                  const Space(),
                                                ],
                                              ),
                                            ),
                                          ])
                                  ),

                                ),
                                // Text(
                                //     'Successfully booked a Register letter of \u{20B9}${widget.amountToBeCollected} with Article Number ${widget.articleNumber}'),
                                actions: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                    Button1(
                                        buttonText: 'PRINT',
                                        buttonFunction: () async {
                                          PrintingTelPO printer =
                                          new PrintingTelPO();
                                          await printer.printThroughUsbPrinter(
                                              "BOOKING",
                                              "Registered Letter",
                                              basicInformation,
                                              secondReceipt,
                                              1);

                                          /* Working PDF Code
                                        print('inside Print Button');
                                        print(pdfName.toString());
                                        await OpenFile.open(pdfName);

                                         */

                                          //print command commented as there is no printer available in mobile device
                                          // final pdf = await rootBundle.load(generatedPdfFilePath.toString());
                                          // await Printing.layoutPdf(onLayout: (_) => pdf.buffer.asUint8List());

                                          // Navigator.pushAndRemoveUntil(
                                          //     context,
                                          //     MaterialPageRoute(
                                          //         builder: (_) => const BookingMainScreen()), (route) => false);
                                        }),
                                    Button1(
                                        buttonText: 'OK',
                                        buttonFunction: () {
                                          Navigator.pushAndRemoveUntil(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (_) =>
                                                  const BookingMainScreen()),
                                                  (route) => false);
                                        }),
                                    Button1(
                                        buttonText: 'Send\nSMS',
                                        buttonFunction: () async {
                                          // //Checking whether Mobile Number entered or not
                                          // //print(widget.senderMobileNumber);
                                          // if(widget.senderMobileNumber.length !=10) {
                                          //   print(widget.senderMobileNumber);
                                          //   showDialog<void>(
                                          //     context: context,
                                          //     barrierDismissible: false,
                                          //     builder: (BuildContext context)
                                          //   {
                                          //     return AlertDialog(
                                          //       title: const Text(
                                          //           'Information'),
                                          //       content: Text(
                                          //           'Invalid Mobile Number!'),
                                          //       actions: [
                                          //         Button(
                                          //             buttonText: 'OKAY',
                                          //             buttonFunction: () =>
                                          //                 Navigator.of(context)
                                          //                     .pop()
                                          //         )
                                          //
                                          //
                                          //       ],
                                          //     );
                                          //   });
                                          // }
                                          // else
                                          // {
                                          //   //Send SMS
                                          //   //Get Details from the Database
                                          //   print("Inside Send Booking SMS");
                                          //   String ret="";
                                          //   String poptext="";
                                          //   BookingDBService bs= new BookingDBService();
                                          //   ret= await bs.SendBookingSMS('RL',widget.articleNumber,widget.senderMobileNumber);
                                          //   print(ret);
                                          //   //print("xvacvsdhvcsj");
                                          //   if(ret=="Success")
                                          //     poptext="SMS Sent Successfully!";
                                          //   else
                                          //     poptext="Unable to send SMS !";
                                          //
                                          //   showDialog<void>(
                                          //       context: context,
                                          //       barrierDismissible: false,
                                          //       builder: (BuildContext context)
                                          //       {
                                          //         return AlertDialog(
                                          //           title: const Text(
                                          //               'Information'),
                                          //           content: Text(
                                          //               poptext),
                                          //           actions: [
                                          //             Button(
                                          //                 buttonText: 'OKAY',
                                          //                 buttonFunction: () =>
                                          //                     Navigator.of(context)
                                          //                         .pop()
                                          //             )
                                          //           ],
                                          //         );
                                          //       }
                                          //       );
                                          //
                                          print(_clicked);
                                          // Checking internet availability
                                          bool netresult = false;
                                            netresult =
                                            await InternetConnectionChecker()
                                                .hasConnection;
                                            if (netresult) {
                                          if(_clicked==false)
                                          await SendSms();
                                            }
                                            else{
                                              showDialog<void>(
                                                  context: context,
                                                  barrierDismissible: false,
                                                  builder: (BuildContext context)
                                                  {
                                                    return AlertDialog(
                                                      title: const Text(
                                                          'Information'),
                                                      content: Text(
                                                          'Internet connection is not available..!'),
                                                      actions: [
                                                        Button(
                                                            buttonText: 'OKAY',
                                                            buttonFunction: () =>
                                                                Navigator.of(context)
                                                                    .pop()
                                                        )
                                                      ],
                                                    );
                                                  });
                                            }
                                        }
                                        )
                                  ],),

                                ],
                              );
                            });
                      }),
                ],
              ),
            )
          ],
        ),
      );
}
