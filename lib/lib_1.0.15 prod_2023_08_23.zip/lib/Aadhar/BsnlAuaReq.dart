import 'AuthReqnew.dart';
import 'Validation.dart';

class BsnlAuaReq {
  late ValidationData validationData;

  late AuthReqNew authReqNew;
}
